Archivo 1: package.json

{
  "name": "mi-biblioteca",
  "version": "1.0.0",
  "description": "Biblioteca de libros de Google Drive para Kobo",
  "main": "server.js",
  "scripts": {
    "start": "node server.js"
  },
  "dependencies": {
    "express": "^4.18.2",
    "node-fetch": "^2.6.7"
  },
  "engines": {
    "node": "18.x"
  }
}

Archivo 2: server.js

const express = require('express');
const fetch = require('node-fetch');
const app = express();

// Tus datos de Google Drive
const folderId = '1-4G6gGNtt6KVS90AbWbtH3JlpetHrPEi';
const apiKey = 'AIzaSyBZQnrDOm-40Mk6l9Qt48tObQtjWtM8IdA';

const PORT = process.env.PORT || 3000;

const css = `
body { font-family: 'Georgia', serif; margin:0; padding:20px; background:#f5f3ef; color:#3e3a36; }
header { text-align:center; margin-bottom:20px; }
h1 { color:#c49a6c; font-size:28px; }
#grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(100px,1fr)); gap:24px; }
.libro { background:#fff8f0; border-radius:6px; padding:6px; text-align:center; display:flex; flex-direction:column; }
.placeholder { width:100%; height:160px; border-radius:4px; display:flex; align-items:center; justify-content:center; font-size:48px; }
.titulo { font-size:13px; font-weight:bold; margin:6px 0; overflow:hidden; text-overflow:ellipsis; }
.meta a { display:inline-block; padding:4px 10px; border-radius:20px; text-decoration:none; background:#c49a6c; color:#fff; font-size:12px; }
`;

app.get('/', async (req, res) => {
  try {
    const endpoint = 'https://www.googleapis.com/drive/v3/files';
    const params = new URLSearchParams({
      q: `'${folderId}' in parents and trashed=false`,
      key: apiKey,
      fields: 'files(id,name)',
      pageSize: '1000'
    });

    const response = await fetch(`${endpoint}?${params}`);
    const data = await response.json();

    const colors = ['#c49a6c','#8b5e3c','#d9a066','#a67c4e','#b78e62','#c9b78e','#b07c52'];

    const cards = (data.files || []).map(file => {
      const color = colors[Math.floor(Math.random()*colors.length)];
      return `
      <div class="libro">
        <div class="placeholder" style="background:${color}">📖</div>
        <div class="titulo">${file.name}</div>
        <div class="meta"><a href="https://drive.google.com/uc?export=download&id=${file.id}" target="_blank">Descargar</a></div>
      </div>`;
    }).join('\n');

    const html = `
    <!DOCTYPE html>
    <html lang="es">
    <head>
      <meta charset="UTF-8">
      <title>Mi Biblioteca</title>
      <style>${css}</style>
    </head>
    <body>
      <header>
        <h1>📚 Mi Biblioteca</h1>
        <input id="buscar" type="search" placeholder="Buscar título..." />
      </header>
      <div id="grid">${cards}</div>
      <script>
        const input = document.getElementById('buscar');
        input.addEventListener('input', e => {
          const q = e.target.value.toLowerCase();
          document.querySelectorAll('.libro').forEach(card => {
            const title = card.querySelector('.titulo').textContent.toLowerCase();
            card.style.display = title.includes(q) ? '' : 'none';
          });
        });
      </script>
    </body>
    </html>`;
    
    res.send(html);
  } catch(err) {
    console.error(err);
    res.send('<p>Error al cargar los libros.</p>');
  }
});

app.listen(PORT, () => console.log(`Servidor escuchando en puerto ${PORT}`));
